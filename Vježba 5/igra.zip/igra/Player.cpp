#include <iostream>
#include "Player.h"

Player::Player(std::string n, Level& l)
    : name(n), level(l) {
}

void Player::print() const {
    std::cout << "Igrac: " << name << '\n';
}
