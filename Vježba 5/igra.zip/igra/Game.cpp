#include "Game.h"
#include <iostream>

Game::Game(std::string n, std::string player_name)
    : name(n), level(), player(player_name, level) {
}

void Game::print() const {
    std::cout << name << '\n';
    player.print();
    std::cout << "Level: neprijatelja " << level.enemy_count()
              << ", oruzja " << level.weapon_count() << '\n';
}