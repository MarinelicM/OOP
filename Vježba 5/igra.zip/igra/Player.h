#pragma once      // header se ukljucuje samo jednom, iako ga ukljucuje vise datoteka

#include <string>
#include "Level.h"

class Player {
private:
    std::string name;
    Level& level;

public:
    Player(std::string n, Level& l);
    void print() const;
};
