#pragma once      // header se ukljucuje samo jednom, iako ga ukljucuje vise datoteka

class Enemy {
    // data memberi

public:
    Enemy();
};
