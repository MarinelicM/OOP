#pragma once      // header se ukljucuje samo jednom, iako ga ukljucuje vise datoteka

#include <string>
#include "Level.h"
#include "Player.h"

class Game {
    private:
    std::string name;
    Level level;
    Player player;

public:
    Game(std::string n, std::string player_name);
    void print() const;
};
